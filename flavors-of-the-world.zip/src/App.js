import React, { useState } from 'react';

const episodes = [
  {
    id: "ep1",
    title: "Guyanese Pepperpot",
    country: "Guyana",
    category: "Stews",
    description: "A slow-cooked meat stew made with cassareep and rich spices.",
    videoLink: "https://www.youtube.com/watch?v=gfKnZ3ME78M",
    recipe: [
      "2 lbs beef or oxtail",
      "1 cup cassareep",
      "1 onion, chopped",
      "4 cloves garlic",
      "Cinnamon sticks",
      "Cloves",
      "Wiri wiri peppers",
      "Salt and water to taste"
    ]
  },
  {
    id: "ep2",
    title: "Spaghetti alla Carbonara",
    country: "Italy",
    category: "Pasta",
    description: "A creamy Roman pasta dish made with eggs, Pecorino, guanciale, and pepper.",
    videoLink: "https://www.youtube.com/watch?v=3AAdKl1UYZs",
    recipe: [
      "400g spaghetti",
      "3 egg yolks",
      "100g guanciale or pancetta",
      "50g Pecorino Romano cheese",
      "Freshly cracked black pepper"
    ]
  }
];

function App() {
  const [selectedEpisode, setSelectedEpisode] = useState(episodes[0]);

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Flavors of the World</h1>
      <p>Explore delicious recipes from around the globe!</p>
      <div>
        {episodes.map(ep => (
          <button key={ep.id} onClick={() => setSelectedEpisode(ep)}>
            {ep.title}
          </button>
        ))}
      </div>
      <div style={{ marginTop: '2rem' }}>
        <h2>{selectedEpisode.title}</h2>
        <p><strong>Origin:</strong> {selectedEpisode.country}</p>
        <p><strong>Category:</strong> {selectedEpisode.category}</p>
        <p>{selectedEpisode.description}</p>
        <a href={selectedEpisode.videoLink} target="_blank" rel="noreferrer">Watch Video</a>
        <h3>Ingredients:</h3>
        <ul>
          {selectedEpisode.recipe.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;